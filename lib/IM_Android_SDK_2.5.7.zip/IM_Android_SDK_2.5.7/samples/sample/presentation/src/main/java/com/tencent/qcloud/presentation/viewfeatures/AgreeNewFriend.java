package com.tencent.qcloud.presentation.viewfeatures;

/**
 * Created by admin on 16/3/11.
 */
public interface AgreeNewFriend extends MvpView {

    void jumpIntoProfileActicity();
}
